<?php
    include("header.php");
?>
<h1>Header Here</h1>
<p>Your content goes here. To edit the navigation and title of the website, you must edit the "header.php" file.</p>
<?php include("footer.php");?>